#!/bin/bash

if [ -z "$1" ] && [ -z "$2" ]; then
	drop_recv=""
	drop_send=""
else
	drop_recv=$1
	drop_send=$2
fi

set -euo pipefail

rm -f send.dat receive.dat sender-packets.log receiver-packets.log

echo "hello world" > send.dat
LD_PRELOAD="./log-packets.so" \
    PACKET_LOG="receiver-packets.log" \
    DROP_PATTERN=$drop_recv \
    ./file-receiver receive.dat 1234 1 &
RECEIVER_PID=$!
sleep .1

LD_PRELOAD="./log-packets.so" \
    PACKET_LOG="sender-packets.log" \
    DROP_PATTERN=$drop_send \
    ./file-sender send.dat localhost 1234 1

wait $RECEIVER_PID || true

if diff -qs send.dat receive.dat >/dev/null 2>&1; then
    echo "nice"
else
    echo "oof"
fi

rm -rf send.dat receive.dat
