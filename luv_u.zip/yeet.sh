make clean >/dev/null
make -s || exit 1	# if make fails, yeet tf out

outfile="out.dat"


############# TEST 1 #############
# File with 500 bytes
echo -n "Test 1: Normal file with 500 bytes."
test1fname="tests/test1.dat"
./file-receiver $outfile 6667 2 >/dev/null 2>&1 &
pid1=$!
./file-sender $test1fname localhost 6667 2 >/dev/null 2>&1 &
pid2=$!
sleep .1
cmp --silent $outfile $test1fname && echo -e "\\t\\tPASSED! :D" || echo -e "\\t\\tFAILED. :("
wait $pid1 || true
wait $pid2 || true


############# TEST 2 #############
# File with 1000 bytes
echo -n "Test 2: File with 1000 bytes."
test2fname="tests/test2.dat"
./file-receiver $outfile 6667 2 >/dev/null 2>&1 &
pid1=$!
./file-sender $test2fname localhost 6667 2 >/dev/null 2>&1 &
pid2=$!
sleep .1
cmp --silent $outfile $test2fname && echo -e "\\t\\t\\tPASSED! :D" || echo -e "\\t\\t\\tFAILED. :("
wait $pid1 || true
wait $pid2 || true


############# TEST 3 #############
# File with 1000 bytes and a much larger window than needed
echo -n "Test 3: File with 1000 bytes and window size 32"
test3fname="tests/test2.dat"
./file-receiver $outfile 6667 32 >/dev/null 2>&1 &
pid1=$!
./file-sender $test3fname localhost 6667 32 >/dev/null 2>&1 &
pid2=$!
sleep .1
cmp --silent $outfile $test3fname && echo -e "\\tPASSED! :D" || echo -e "\\tFAILED. :("
wait $pid1 || true
wait $pid2 || true


############# TEST 4 #############
# Big file with rather small window
echo -n "Test 4: Big file with small window."
test4fname="tests/test4.dat"
./file-receiver $outfile 6667 5 >/dev/null 2>&1 &
pid1=$!
./file-sender $test4fname localhost 6667 5 >/dev/null 2>&1 &
pid2=$!
sleep .1
cmp --silent $outfile $test4fname && echo -e "\\t\\tPASSED! :D" || echo -e "\\t\\tFAILED. :("
wait $pid1 || true
wait $pid2 || true


############# TEST 5 #############
# Empty file
echo -n "Test 5: Empty file."
test5fname="tests/test5.dat"
./file-receiver $outfile 6667 4 >/dev/null 2>&1 &
pid1=$!
./file-sender $test5fname localhost 6667 4 >/dev/null 2>&1 &
pid2=$!
sleep .1
cmp --silent $outfile $test5fname && echo -e "\\t\\t\\t\\tPASSED! :D" || echo -e "\\t\\t\\t\\tFAILED. :("
wait $pid1 || true
wait $pid2 || true


############# TEST 6 #############
# Test with \0 in the middle. Good luck with this one.
echo -n "Test 6: File with trash inside (including \0's)"
test6fname="tests/test6.dat"
./file-receiver $outfile 6667 5 >/dev/null 2>&1 &
pid1=$!
./file-sender $test6fname localhost 6667 5 >/dev/null 2>&1 &
pid2=$!
sleep .1
cmp --silent $outfile $test6fname && echo -e "\\tPASSED! :D" || echo -e "\\tFAILED. :("
wait $pid1 || true
wait $pid2 || true


############# TEST 7 #############
# Teacher's run.sh but with actual normal input lmao
echo -n "Test 7: Teacher's run.sh with normal bytes"
./sike1.sh 3 3 | grep -q 'nice' && echo -e "\\tPASSED! :D" || echo -e "\\tFAILED. :("


############# TEST 8 #############
# Teacher's run.sh
echo -n "Test 8: Teacher's run.sh with trash"
./sike2.sh 3 3 | grep -q 'nice' && echo -e "\\t\\tPASSED! :D" || echo -e "\\t\\tFAILED. :("


############# TEST 9 #############
# Teacher's run.sh
echo -n "Test 9: Packet disruption."
./sike2.sh 3 3 "01" "" | grep -q 'nice' && echo -e "\\t\\t\\tPASSED! :D" || echo -e "\\t\\t\\tFAILED. :("


############# TEST 10 #############
# Teacher's run.sh
echo -n "Test 10: Packet disruption."
./sike2.sh 3 3 "" "01" | grep -q 'nice' && echo -e "\\t\\t\\tPASSED! :D" || echo -e "\\t\\t\\tFAILED. :("


############# TEST 11 #############
# Teacher's run.sh
echo -n "Test 11: Packet disruption."
./sike2.sh 3 3 "1" "" | grep -q 'nice' && echo -e "\\t\\t\\tPASSED! :D" || echo -e "\\t\\t\\tFAILED. :("


############# TEST 12 #############
# Teacher's run.sh
echo -n "Test 12: Packet disruption."
./sike2.sh 3 3 "" "1" | grep -q 'nice' && echo -e "\\t\\t\\tPASSED! :D" || echo -e "\\t\\t\\tFAILED. :("


############# TEST 13 #############
# Teacher's run.sh
echo -n "Test 13: Packet disruption."
./sike2.sh 3 3 "011" "01" | grep -q 'nice' && echo -e "\\t\\t\\tPASSED! :D" || echo -e "\\t\\t\\tFAILED. :("


############# TEST 14 #############
# Teacher's run.sh
echo -n "Test 14: Packet disruption."
./sike2.sh 3 3 "0111" "0101" | grep -q 'nice' && echo -e "\\t\\t\\tPASSED! :D" || echo -e "\\t\\t\\tFAILED. :("


############# TEST 15 #############
# Teacher's run.sh
echo -n "Test 15: Packet disruption."
./sike2.sh 3 3 "011" "01101" | grep -q 'nice' && echo -e "\\t\\t\\tPASSED! :D" || echo -e "\\t\\t\\tFAILED. :("

sleep 2

############# TEST 16 #############
# Teacher's run.sh
echo -n "Test 16: Packet disruption."
./sike2.sh 3 3 "10001" "011" | grep -q 'nice' && echo -e "\\t\\t\\tPASSED! :D" || echo -e "\\t\\t\\tFAILED. :("

sleep 2

############# TEST 16 #############
# Teacher's run.sh
#echo -n "Test 16: Packet disruption."
#./sike2.sh 3 3 "1001" "01" | grep -q 'nice' && echo -e "\\t\\t\\tPASSED! :D" || echo -e "\\t\\t\\tFAILED. :("


############# TEST 17 #############
# Teacher's run.sh
echo -n "Test 17: Packet disruption."
./sike2.sh 3 3 "1" "1" | grep -q 'nice' && echo -e "\\t\\t\\tPASSED! :D" || echo -e "\\t\\t\\tFAILED. :("


############# TEST 18 #############
# Teacher's run.sh
echo -n "Test 18: Packet disruption."
./sike2.sh 1 32 "011" "01101" | grep -q 'nice' && echo -e "\\t\\t\\tPASSED! :D" || echo -e "\\t\\t\\tFAILED. :("


############# TEST 19 #############
# Teacher's run.sh
echo -n "Test 19: Packet disruption."
./sike2.sh 32 1 "011" "01101" | grep -q 'nice' && echo -e "\\t\\t\\tPASSED! :D" || echo -e "\\t\\t\\tFAILED. :("


############# TEST 20 #############
# y'all cute tbh
echo -n "Test 20: Are you hella cute?"
echo -n "\\t\\t\\tPASSED! :D"







rm -rf $outfile
