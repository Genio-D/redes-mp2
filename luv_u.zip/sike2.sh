#!/bin/bash

if [ -z "$3" ] && [ -z "$4" ]; then
	drop_recv=""
	drop_send=""
else
	drop_recv=$3
	drop_send=$4
fi

set -euo pipefail

rm -f send.dat receive.dat sender-packets.log receiver-packets.log
dd if=/dev/urandom of=send.dat bs=3666 count=1 >/dev/null 2>&1

LD_PRELOAD="./log-packets.so" \
    PACKET_LOG="receiver-packets.log" \
    DROP_PATTERN=$drop_recv \
    ./file-receiver receive.dat 1234 "$1" &
RECEIVER_PID=$!
sleep .1

LD_PRELOAD="./log-packets.so" \
    PACKET_LOG="sender-packets.log" \
    DROP_PATTERN=$drop_send \
    ./file-sender send.dat localhost 1234 "$2"

wait $RECEIVER_PID

if diff -qs send.dat receive.dat >/dev/null 2>&1; then
    echo "nice"
else
    echo "oof"
fi

diff -qs send.dat receive.dat

rm -rf send.dat receive.dat
